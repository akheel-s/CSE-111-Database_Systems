SELECT COUNT(*)
FROM lineitem
WHERE l_commitdate > l_shipdate