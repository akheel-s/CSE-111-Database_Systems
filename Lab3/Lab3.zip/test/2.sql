SELECT MIN(s_acctbal) as s_acctbal 
FROM supplier